# HW2: 共享單車需求預測 (Bike Sharing Demand Prediction)
## 多元線性迴歸 (Multiple Linear Regression) 與特徵選取 (Feature Selection)

---

### 1. 專案概述 (Project Overview)
本研究以智慧城市交通微型移動為核心背景，針對 **Capital Bikeshare** 系統之每小時共享單車租借需求進行預測。透過標準的 **CRISP-DM** 六大階段，建構多元線性迴歸 (Multiple Linear Regression) 基準模型，比較五種特徵選取演算法，並引入具嚴謹統計覆蓋保證之 **獨立校準集分割共形預測 (Split Conformal Prediction)**，產出 95% 預測區間。

- **資料集來源**：[Kaggle Bike Sharing Dataset](https://www.kaggle.com/datasets/lakshmi25npathi/bike-sharing-dataset) / UCI Machine Learning Repository (`hour.csv`)
- **預測目標變數**：`cnt` (每小時總借車需求數量)
- **程式碼檔案**：`main.py` 與作業繳交腳本 `StudentID_hw2.py`

---

### 2. 目錄架構 (Project Structure)
```
HW2_Bike_Sharing/
├── main.py                               # 核心執行程式碼 (完整 CRISP-DM 流程)
├── StudentID_hw2.py                      # 作業繳交命名腳本 (保留學號佔位符)
├── requirements.txt                      # 專案相依套件清單
├── README.md                             # 專案完整技術說明文件
├── data/                                 # 資料集目錄
│   ├── hour.csv                          # 每小時單車需求核心資料 (17,379 筆)
│   ├── day.csv                           # 每日匯總資料 (731 筆)
│   ├── Readme.txt                        # UCI 原始資料集欄位定義文檔
│   └── bike_sharing_dataset.zip          # 原始下載壓縮包
├── results/                              # 評估報表與高品質圖表
│   ├── baseline_linear_regression_metrics.csv # 基準模型各資料集指標表
│   ├── feature_selection_comparison_all.csv   # 5 種方法在所有 k 階特徵子集表現
│   ├── best_models_per_method.csv             # 各方法最優特徵數與驗證集效能
│   ├── feature_coefficients.csv               # 最佳特徵子集之標準化迴歸係數
│   ├── test_prediction_intervals.csv          # 測試集實際值、預測值與 95% 預測上下限
│   ├── eda_target_distribution.png            # 目標變數分佈與箱形圖
│   ├── eda_hourly_demand.png                  # 工作日 vs 假日雙峰需求曲線
│   ├── eda_seasonal_weather.png               # 季節與天候狀態需求差異
│   ├── eda_correlation_heatmap.png            # Pearson 相關係數熱圖
│   ├── feature_selection_rmse_vs_k.png        # 特徵數 k vs 驗證集 RMSE 變化圖
│   ├── feature_selection_r2_vs_k.png          # 特徵數 k vs 驗證集 R² 變化圖
│   ├── train_vs_val_performance.png           # 訓練集 vs 驗證集 RMSE 趨勢診斷圖
│   ├── prediction_interval_95.png             # 測試集前一週 (168h) 95% 預測區間時序圖
│   ├── actual_vs_predicted_scatter.png        # 測試集實際值 vs 預測值散佈圖 (y = x)
│   ├── residual_distribution.png              # 殘差分佈與常態分佈擬合圖
│   ├── residuals_vs_predicted.png             # 殘差 vs 預測值 (異質變異檢驗圖)
│   └── feature_importance_coefficients.png    # 特徵重要性長條圖 (標準化 Beta)
├── models/                               # 序列化持久化模型
│   ├── baseline_linear_regression.joblib      # 基準多元線性迴歸模型
│   ├── best_linear_regression.joblib          # 最優特徵子集線性迴歸模型
│   └── feature_scaler.joblib                  # 訓練集擬合之標準化轉換器
├── web/                                  # 互動成果呈現網頁
│   ├── index.html                             # 儀表板前端主頁 (含 OLS / VIF / 模擬器)
│   ├── style.css                              # 現代深淺色玻璃擬態樣式表
│   └── app.js                                 # 前端即時推論與共形區間計算邏輯
└── web_server.py                         # 本地輕量 HTTP 網頁伺服器
```

---

### 3. CRISP-DM 六大階段實作細節

#### 階段一：業務理解 (Business Understanding)
- **痛點**：都市共享單車具強烈潮汐通勤效應與天氣敏感性，供需失衡將直接導致調度成本飆升或民怨。
- **目標**：以具可解釋性之多元線性迴歸模型預測每小時總租借量 `cnt`，並提供統計學保證之 95% 預測區間以輔助營運備車決策。

#### 階段二：資料理解 (Data Understanding & EDA)
- 資料筆數：17,379 筆每小時紀錄 (2011/01/01 至 2012/12/31)，無缺失值。
- 共線性發現：`temp` (溫度) 與 `atemp` (體感溫度) 相關係數高達 **0.9877**，呈現極度嚴重之共線性 (Multicollinearity)。
- 需求模式：工作日呈現顯著「早尖峰 (8-9時)」與「晚尖峰 (17-18時)」之雙峰分佈，假日則呈現平緩午後單峰。

#### 階段三：資料準備與防範外洩 (Data Preparation & Leakage Prevention)
1. **防止目標外洩 (Target Leakage)**：
   - 嚴格剔除 `casual` (散客) 與 `registered` (會員)，因兩者相加恆等於目標 `cnt`。
2. **剔除流水號**：剔除 `instant` 避免模型學習偽趨勢。
3. **防止時序外洩 (Data Leakage)**：
   - 拒絕隨機打亂 (Random Shuffling)，嚴格依時間順序切分：
     - **訓練集 (Train)**：前 60.0% (10,427 筆, 2011-01-01 至 2012-03-15)
     - **驗證集 (Validation)**：次 15.0% (2,606 筆, 2012-03-15 至 2012-07-02) - 用於特徵選取與選定最佳特徵數 $k^*$
     - **校準集 (Calibration)**：次 10.0% (1,737 筆, 2012-07-02 至 2012-09-12) - 專屬共形預測殘差校準
     - **測試集 (Test)**：末 15.0% (2,609 筆, 2012-09-12 至 2012-12-31) - 獨立未接觸之未來測試集
4. **特徵工程 (共構建 18 個輸入特徵，符合 10~20 規定)**：
   - 日曆趨勢：`yr`、`holiday`、`workingday`
   - 氣象數值：`temp`、`atemp`、`hum`、`windspeed`
   - 虛擬變數：`season_summer`、`season_fall`、`season_winter` (基底為春季)；`weather_mist`、`weather_bad` (基底為晴朗)
   - 週期諧波：24小時週期 `hr_sin`、`hr_cos`；12小時通勤諧波 `hr_sin2`、`hr_cos2`
   - 交互特徵：工作日尖峰指示器 `is_rush_hour`、溫濕度交互項 `temp_hum`

#### 階段四：多元線性迴歸與五種特徵選取 (Modeling & Feature Selection)
實作五種特徵選取方法，並以未正則化之 `LinearRegression` 作為子集最終預測模型：
1. **Lasso (L1 Regularization)**
2. **Forward Sequential Feature Selection (Forward SFS)**
3. **Recursive Feature Elimination (RFE)**
4. **ElasticNet (L1 + L2 Regularization)**
5. **Exhaustive Feature Search (有限計算界限窮舉搜尋, $k=1 \dots 6$)**

#### 階段五：模型評估與 95% 共形預測區間 (Evaluation & Split Conformal Prediction)
- 統計公式：在獨立校準集上計算絕對非一致性殘差 $s_i = |y_{cal, i} - \hat{y}_{cal, i}|$。
- 95% 共形臨界分位數：$q = \text{Quantile}_{\lceil (n+1)(1-\alpha)\rceil / n}(\{s_i\}) = 318.81$ 輛。
- 獨立未來測試集實證覆蓋率：**94.40%** (名義水準 95.0%)，平均區間寬度 525.99 輛。

#### 階段六：部署考量 (Deployment)
- 矩陣內積推論耗時小於 0.1 毫秒，具極高即時性。
- 提供上線監控機制、滑動視窗再校準機制與概念漂移檢測機制。

---

### 4. 關鍵實驗指標總覽 (Key Metrics)

| 評估階段 | 模型 / 特徵數 | 均方根誤差 (RMSE) | 判定係數 ($R^2$) | 平均絕對誤差 (MAE) | 備註 |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **訓練集 (Train)** | 全特徵 Baseline ($k=18$) | 73.84 | 0.6991 | 55.62 | 2011/01 ~ 2012/03 |
| **驗證集 (Validation)** | 全特徵 Baseline ($k=18$) | 133.72 | 0.6131 | 102.94 | 用於挑選最優特徵數 |
| **測試集 (Test)** | 全特徵 Baseline ($k=18$) | 138.99 | 0.5824 | 100.92 | 2012/09 ~ 2012/12 未來預測 |
| **測試集 95% 共形覆蓋** | 最優模型 ($k=18$) | **94.40%** 覆蓋率 | 臨界值 $q=\pm 318.8$ 輛 | 平均寬度 526.0 輛 | 絕非人為捏造常數 |

---

### 5. 環境安裝與重現指令 (How to Run)

#### Step 1: 安裝相依套件
```bash
pip install -r requirements.txt
```

#### Step 2: 執行完整模型管線
```bash
python main.py
```
*(或直接執行繳交檔案：`python StudentID_hw2.py`)*

#### Step 3: 啟動互動成果展示網頁
```bash
python web_server.py
```
*(在本地瀏覽器訪問：`http://localhost:8080`)*

---

### 6. 繳交作業檢查清單 (Submission Checklist)
- [x] `StudentID_hw2.py`：包含完整資料清洗、五種特徵選取、多元線性迴歸、共形預測與圖表輸出程式碼。
- [x] `requirements.txt`：列出執行所需相依套件。
- [x] `README.md`：提供完整繁體中文專案說明、重現指引與 StatsUnlock 版面參考致謝。
- [x] `results/`：包含 12 張評估圖檔與 6 份 CSV 評估與共線性報表。
- [x] `web/`：互動式成果呈現儀表板與即時預測模擬器。
- [x] `StudentID_hw2.zip`：整合程式碼、互動網頁、模型與成果圖表之標準格式壓縮檔。
- [ ] **學生個人完成項目**：
  - 將檔名與腳本中之 `StudentID` 替換為個人真實學號。
  - **手寫學術報告 (Handwritten Report)**：依據作業規定手寫完成紙本或掃描報告。
  - 於報告手寫區塊附上 NotebookLM 摘要 (至少 100 字) 與 GPT 提問歷程。

---

### 7. 互動成果呈現網頁與設計參考說明 (Interactive Web & Design Attribution)

本專案實作了高品質之資料科學互動式成果呈現網頁 (Interactive Web Dashboard)，提供評審委員與使用者即時體驗多元線性迴歸推論、特徵選取錦標賽評估、共線性 (VIF) 診斷與 95% 共形預測區間。

- **版面設計參考來源**：
  - 參考網站：[StatsUnlock — Multiple Linear Regression Calculator](https://statsunlock.com/multiple-linear-regression-calculator/)
  - **參考版面特色與技術吸納**：
    1. **OLS 模型摘要統計卡片 (Model Summary Cards)**：呈現 $R^2$、Adjusted $R^2$、$F$-statistic、$p$-value、RMSE 及 $n/k$ 樣本比，並搭配顯著性判定橫幅 (Statistical Significance Banner)。
    2. **彩色標記數學迴歸方程式 (Mathematical Equation Banner)**：視覺化呈現標準化/未標準化迴歸方程式 $\hat{Y} = b_0 + b_1 X_1 + \dots$，直觀展示各變數對借車量之邊際貢獻。
    3. **完整迴歸係數與共線性檢驗表 (Coefficients & VIF Table)**：完整輸出未標準化係數 ($B$)、標準誤 ($SE$)、標準化係數 ($\beta$)、$t$ 統計量、$p$ 值、95% 信賴區間，以及**變異數膨脹因子 (VIF, Variance Inflation Factor)**，並提供色彩預警標籤 (VIF > 10 標記為嚴重共線性)。
    4. **ANOVA 變異數分解表 (Analysis of Variance)**：輸出迴歸 (Regression)、殘差 (Residual) 與總變異 (Total) 之平方和 ($SS$)、自由度 ($df$)、均方 ($MS$) 與 $F$ 檢定。
    5. **四大經典統計診斷圖 (Diagnostic Visualizations)**：預測值 vs 實際值 (1:1 參考線)、殘差 vs 擬合值 (異質變異檢驗)、標準化係數重要性條形圖、殘差常態分佈與鐘形曲線。
    6. **模型假設檢驗 (Assumption Checks)**：採用燈號檢視共線性 (VIF)、殘差獨立性 (Durbin-Watson)、殘差常態性 (Skewness) 與樣本規模比。
    7. **學術報告與 APA 7 寫作範例 (Academic Reporting)**：提供標準 APA 格式之統計推論論述範例與結論詮釋。
    8. **即時情境模擬器 (What-If Interactive Calculator)**：允許使用者自由調整小時、氣溫、濕度、風速、工作日、季節與天氣，毫秒級即時計算點預測值與 95% 共形預測區間 $[ \max(0, \hat{y} - q), \hat{y} + q ]$。

- **啟動互動網頁服務方式**：
  ```bash
  python web_server.py
  ```
  在本地瀏覽器開啟：`http://localhost:8080` (亦可支援手機/平板響應式瀏覽)。

